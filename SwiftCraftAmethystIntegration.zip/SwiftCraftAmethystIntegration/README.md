# SwiftCraft + Amethyst integration attempt

This kit adds a SwiftCraft-branded native Android home Activity **inside the Amethyst source build**, rather than launching a separately installed Amethyst app. It builds Amethyst from source in GitHub Actions and uploads the resulting debug APK.

## Important limitation

The SwiftCraft home screen is integrated into the same APK and keeps the original Amethyst Activity available internally. The Play button currently hands off to that original Activity. Directly starting Minecraft without showing Amethyst's launcher requires adapting to Amethyst's internal game-start callback and runtime configuration APIs; this kit does not guess those private interfaces. The version/RAM/touch/mod preferences are saved but are not yet mapped into the actual runtime.

## Build
1. Download/extract this ZIP.
2. Upload its contents to a new GitHub repository.
3. Open Actions → **Build SwiftCraft-integrated Amethyst APK** → Run workflow.
4. Download the `SwiftCraft-Amethyst-debug-apk` artifact after the job succeeds.

The workflow requires GitHub Actions to access the network for the Amethyst recursive clone and Gradle dependencies. The APK is not prebuilt in this ZIP.

Amethyst is LGPLv3; preserve license notices when redistributing. This project does not bundle Minecraft assets or bypass account authentication/licensing.
