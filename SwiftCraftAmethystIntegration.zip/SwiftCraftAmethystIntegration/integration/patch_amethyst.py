#!/usr/bin/env python3
"""Add a SwiftCraft home screen to Amethyst's app module and make it the entry point.

It preserves the original Amethyst launcher Activity inside the same APK. This is a
partial integration: direct game-launch/runtime configuration API calls are not guessed.
"""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
ANDROID = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ANDROID)
A = '{%s}' % ANDROID

def main():
    repo = Path(sys.argv[1] if len(sys.argv) > 1 else 'Amethyst-Android')
    app = repo / 'app_pojavlauncher'
    manifest = app / 'src/main/AndroidManifest.xml'
    if not manifest.is_file(): raise SystemExit(f'Manifest not found: {manifest}')
    namespace = None
    for f in (app/'build.gradle.kts', app/'build.gradle'):
        if f.exists():
            m = re.search(r'namespace\s*(?:=\s*)?["\']([^"\']+)["\']', f.read_text(errors='replace'))
            if m: namespace = m.group(1); break
    tree = ET.parse(manifest); root = tree.getroot(); appnode = root.find('application')
    if appnode is None: raise SystemExit('No <application> found')
    namespace = namespace or root.get('package')
    if not namespace: raise SystemExit('Could not determine app namespace')
    original = None
    for activity in list(appnode):
        if activity.tag not in ('activity', 'activity-alias'): continue
        for filt in list(activity.findall('intent-filter')):
            actions = [x.get(A+'name') for x in filt.findall('action')]
            cats = [x.get(A+'name') for x in filt.findall('category')]
            if 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in cats:
                original = activity.get(A+'name'); activity.remove(filt); break
        if original: break
    if not original: raise SystemExit('Could not find original MAIN/LAUNCHER activity')
    if original.startswith('.'):
        original_fqcn = namespace + original
    elif '.' not in original:
        original_fqcn = namespace + '.' + original
    else: original_fqcn = original
    src = app / 'src/main/java' / Path(*namespace.split('.'))
    src.mkdir(parents=True, exist_ok=True)
    template = (Path(__file__).with_name('SwiftCraftHomeActivity.kt.template')).read_text()
    (src/'SwiftCraftHomeActivity.kt').write_text(template.replace('__NAMESPACE__', namespace).replace('__ORIGINAL_ACTIVITY__', original_fqcn))
    new = ET.SubElement(appnode, 'activity', {A+'name': '.SwiftCraftHomeActivity', A+'exported':'true'})
    filt = ET.SubElement(new, 'intent-filter')
    ET.SubElement(filt, 'action', {A+'name':'android.intent.action.MAIN'})
    ET.SubElement(filt, 'category', {A+'name':'android.intent.category.LAUNCHER'})
    tree.write(manifest, encoding='utf-8', xml_declaration=True)
    print(f'Patched {manifest}; preserved backend activity {original_fqcn}; added {namespace}.SwiftCraftHomeActivity')
if __name__ == '__main__': main()
